package com.nightonke.saver.ui;

import android.view.View;

/**
 * Created by Weiping on 2016/1/26.
 */
public class SwipeableItemOnClickListener implements View.OnClickListener {

    private int position;

    public SwipeableItemOnClickListener() {
    }

    public SwipeableItemOnClickListener(int position) {
        this.position = position;
    }

    @Override
    public void onClick(View v) {

    }
}
